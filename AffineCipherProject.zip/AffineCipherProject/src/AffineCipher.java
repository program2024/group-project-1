import java.util.Scanner;

public class AffineCipher {
    // Function to find GCD of two numbers
    public static int gcd(int a, int b) {
        if (b == 0)
            return a;
        return gcd(b, a % b);
    }

    // Function to find modular inverse of a (mod m)
    public static int modInverse(int a, int m) {
        a = a % m;
        for (int x = 1; x < m; x++)
            if ((a * x) % m == 1)
                return x;
        return 1;
    }

    // Function to encrypt the plaintext
    public static String encrypt(String plaintext, int key1, int key2) {
        StringBuilder ciphertext = new StringBuilder();
        for (int i = 0; i < plaintext.length(); i++) {
            char ch = plaintext.charAt(i);
            if (ch != ' ') {
                // Apply the affine cipher formula
                ch = (char) (((key1 * (ch - 'A')) + key2) % 26 + 'A');
            }
            ciphertext.append(ch);
        }
        return ciphertext.toString();
    }

    // Function to decrypt the ciphertext
    public static String decrypt(String ciphertext, int key1, int key2) {
        StringBuilder plaintext = new StringBuilder();
        int modInverseKey1 = modInverse(key1, 26);
        for (int i = 0; i < ciphertext.length(); i++) {
            char ch = ciphertext.charAt(i);
            if (ch != ' ') {
                // Apply the decryption formula
                ch = (char) (((modInverseKey1 * (ch - 'A' - key2)) % 26 + 26) % 26 + 'A');
            }
            plaintext.append(ch);
        }
        return plaintext.toString();
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input the plaintext
        System.out.print("Enter the plaintext: ");
        String plaintext = scanner.nextLine().toUpperCase();

        // Input the keys
        System.out.print("Enter the first key (a): ");
        int key1 = scanner.nextInt();
        System.out.print("Enter the second key (b): ");
        int key2 = scanner.nextInt();

        // Check if key1 is coprime with 26
        if (gcd(key1, 26) != 1) {
            System.out.println("Error: Key 1 should be coprime with 26.");
            return;
        }

        // Encrypt the plaintext
        String encryptedText = encrypt(plaintext, key1, key2);
        System.out.println("Encrypted text: " + encryptedText);

        // Decrypt the ciphertextt(plaintext, ke
        String decryptedText = decrypt(encryptedText, key1, key2);
        System.out.println("Decrypted text: " + decryptedText);
    }
}
