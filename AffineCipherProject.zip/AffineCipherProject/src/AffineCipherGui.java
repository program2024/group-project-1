
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.BitSet;
import java.util.InputMismatchException;
import java.util.Random;
import javax.swing.JOptionPane;

public class AffineCipherGui extends javax.swing.JFrame {
    
    public AffineCipherGui() {
        initComponents();
        setResizable(false);
        setLocationRelativeTo(null);
        getContentPane().setBackground(Color.white);
        ciphertextLabel.setText("");
        decryptedLabel.setText("");

        //calculate button
        calculateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    String plaintext = textInput.getText().toString();
                    if (plaintext.isEmpty()) {
                        message("Enter plain text");
                        return;
                    }
                    plaintext = plaintext.toUpperCase();
                    int key1 = Integer.parseInt(keyInput1.getText());
                    int key2 = Integer.parseInt(key2Input.getText());

                    // Check if key1 is coprime with 26
                    if (gcd(key1, 26) != 1) {
                        message("Error: Key 1 should be coprime with 26.");
                        return;
                    }

                    // Encrypt the plaintext
                    String encryptedText = encrypt(plaintext, key1, key2);
                    ciphertextLabel.setText("Encrypted text: " + encryptedText);

                    // Decrypt the ciphertextt(plaintext, ke
                    String decryptedText = decrypt(encryptedText, key1, key2);
                    decryptedLabel.setText("Decrypted text: " + decryptedText);
                    
                } catch (NumberFormatException ex) {
                    message("Key Must be number");
                    
                }
            }
        });
        
    }
    
    private void message(String msg) {
        JOptionPane.showMessageDialog(rootPane, msg, "Affine Cipher", JOptionPane.ERROR_MESSAGE);
    }

    // Function to find GCD of two numbers
    public static int gcd(int a, int b) {
        if (b == 0) {
            return a;
        }
        return gcd(b, a % b);
    }

    // Function to find modular inverse of a (mod m)
    public static int modInverse(int a, int m) {
        a = a % m;
        for (int x = 1; x < m; x++) {
            if ((a * x) % m == 1) {
                return x;
            }
        }
        return 1;
    }

    // Function to encrypt the plaintext
    public static String encrypt(String plaintext, int key1, int key2) {
        StringBuilder ciphertext = new StringBuilder();
        for (int i = 0; i < plaintext.length(); i++) {
            char ch = plaintext.charAt(i);
            if (ch != ' ') {
                // Apply the affine cipher formula
                ch = (char) (((key1 * (ch - 'A')) + key2) % 26 + 'A');
            }
            ciphertext.append(ch);
        }
        return ciphertext.toString();
    }

    // Function to decrypt the ciphertext
    public static String decrypt(String ciphertext, int key1, int key2) {
        StringBuilder plaintext = new StringBuilder();
        int modInverseKey1 = modInverse(key1, 26);
        for (int i = 0; i < ciphertext.length(); i++) {
            char ch = ciphertext.charAt(i);
            if (ch != ' ') {
                // Apply the decryption formula
                ch = (char) (((modInverseKey1 * (ch - 'A' - key2)) % 26 + 26) % 26 + 'A');
            }
            plaintext.append(ch);
        }
        return plaintext.toString();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel00 = new javax.swing.JLabel();
        label_1 = new javax.swing.JLabel();
        textInput = new javax.swing.JTextField();
        calculateButton = new javax.swing.JButton();
        ciphertextLabel = new javax.swing.JLabel();
        decryptedLabel = new javax.swing.JLabel();
        keyInput1 = new javax.swing.JTextField();
        label_2 = new javax.swing.JLabel();
        key2Input = new javax.swing.JTextField();
        label_3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel00.setFont(new java.awt.Font("Tahoma", 1, 28)); // NOI18N
        jLabel00.setForeground(new java.awt.Color(0, 153, 153));
        jLabel00.setText("Affine Cipher");

        label_1.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        label_1.setForeground(new java.awt.Color(0, 51, 51));
        label_1.setText("Enter the first key (a): ");

        textInput.setFont(new java.awt.Font("Tahoma", 0, 22)); // NOI18N
        textInput.setForeground(new java.awt.Color(0, 153, 153));
        textInput.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        calculateButton.setBackground(new java.awt.Color(0, 153, 153));
        calculateButton.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        calculateButton.setForeground(new java.awt.Color(255, 255, 255));
        calculateButton.setText("Start");
        calculateButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                calculateButtonActionPerformed(evt);
            }
        });

        ciphertextLabel.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        ciphertextLabel.setForeground(new java.awt.Color(0, 153, 153));
        ciphertextLabel.setText("enc");

        decryptedLabel.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        decryptedLabel.setForeground(new java.awt.Color(0, 51, 51));
        decryptedLabel.setText("dyc");

        keyInput1.setFont(new java.awt.Font("Tahoma", 0, 22)); // NOI18N
        keyInput1.setForeground(new java.awt.Color(0, 153, 153));
        keyInput1.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        label_2.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        label_2.setForeground(new java.awt.Color(0, 51, 51));
        label_2.setText("Enter the plaintext: ");

        key2Input.setFont(new java.awt.Font("Tahoma", 0, 22)); // NOI18N
        key2Input.setForeground(new java.awt.Color(0, 153, 153));
        key2Input.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        label_3.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        label_3.setForeground(new java.awt.Color(0, 51, 51));
        label_3.setText("Enter the second key (b): ");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(label_2)
                    .addComponent(jLabel00))
                .addGap(321, 321, 321))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(46, 46, 46)
                        .addComponent(keyInput1, javax.swing.GroupLayout.PREFERRED_SIZE, 273, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(82, 82, 82)
                        .addComponent(label_1)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 138, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(key2Input, javax.swing.GroupLayout.PREFERRED_SIZE, 273, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(96, 96, 96))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(label_3)
                        .addGap(116, 116, 116))))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(192, 192, 192)
                        .addComponent(textInput, javax.swing.GroupLayout.PREFERRED_SIZE, 436, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(59, 59, 59)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(decryptedLabel)
                            .addComponent(ciphertextLabel)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(321, 321, 321)
                        .addComponent(calculateButton, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel00)
                .addGap(52, 52, 52)
                .addComponent(label_2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(textInput, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(label_1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(keyInput1, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(label_3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(key2Input, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(55, 55, 55)
                .addComponent(calculateButton, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 58, Short.MAX_VALUE)
                .addComponent(ciphertextLabel)
                .addGap(29, 29, 29)
                .addComponent(decryptedLabel)
                .addGap(42, 42, 42))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void calculateButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_calculateButtonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_calculateButtonActionPerformed
    
    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AffineCipherGui().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton calculateButton;
    private javax.swing.JLabel ciphertextLabel;
    private javax.swing.JLabel decryptedLabel;
    private javax.swing.JLabel jLabel00;
    private javax.swing.JTextField key2Input;
    private javax.swing.JTextField keyInput1;
    private javax.swing.JLabel label_1;
    private javax.swing.JLabel label_2;
    private javax.swing.JLabel label_3;
    private javax.swing.JTextField textInput;
    // End of variables declaration//GEN-END:variables
}
