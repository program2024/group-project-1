import java.util.BitSet;
import java.util.Random;
import java.util.Scanner;

public class FiestelCipher {
    // Block size in bits
    private static final int BLOCK_SIZE = 16;
    // Key size in bits
    private static final int KEY_SIZE = 16;
    // Number of rounds
    private static final int NUM_ROUNDS = 2;

    // Generate a random 16-bit key
    private static BitSet generateRandomKey() {
        Random random = new Random();
        BitSet key = new BitSet(KEY_SIZE);
        for (int i = 0; i < KEY_SIZE; i++) {
            if (random.nextBoolean()) {
                key.set(i);
            }
        }
        return key;
    }

    // Round function: Shift by one byte and XOR operation
    private static BitSet roundFunction(BitSet block, BitSet key) {
        // Shift block by one byte
        block = shiftLeft(block);

        // XOR with key
        block.xor(key);

        return block;
    }

    // Shift left by one byte
    private static BitSet shiftLeft(BitSet bits) {
        int numBytes = bits.length() / 8;
        int numBits = bits.length() % 8;
        BitSet shiftedBits = new BitSet(bits.length());
        for (int i = 0; i < numBytes; i++) {
            for (int j = 0; j < 7; j++) {
                if (bits.get(i * 8 + j + 1)) {
                    shiftedBits.set(i * 8 + j);
                }
            }
            shiftedBits.set((i + 1) * 8 - 1);
        }
        // Handle remaining bits
        for (int i = 0; i < numBits - 1; i++) {
            if (bits.get(numBytes * 8 + i + 1)) {
                shiftedBits.set(numBytes * 8 + i);
            }
        }
        return shiftedBits;
    }

    // Fiestel encryption algorithm
    public static BitSet encrypt(BitSet block, BitSet key1, BitSet key2) {
        BitSet left = block.get(0, BLOCK_SIZE / 2);
        BitSet right = block.get(BLOCK_SIZE / 2, BLOCK_SIZE);

        for (int round = 0; round < NUM_ROUNDS; round++) {
            BitSet temp = (BitSet) right.clone();
            right.xor(roundFunction(left, key1));
            left = (BitSet) temp.clone();
        }

        right.xor(roundFunction(left, key2));

        BitSet encryptedBlock = new BitSet(BLOCK_SIZE);
        encryptedBlock.or(left);
        encryptedBlock.or(right);

        return encryptedBlock;
    }

    // Fiestel decryption algorithm
    public static BitSet decrypt(BitSet block, BitSet key1, BitSet key2) {
        BitSet left = block.get(0, BLOCK_SIZE / 2);
        BitSet right = block.get(BLOCK_SIZE / 2, BLOCK_SIZE);

        right.xor(roundFunction(left, key2));

        for (int round = 0; round < NUM_ROUNDS; round++) {
            BitSet temp = (BitSet) left.clone();
            left.xor(roundFunction(right, key1));
            right = (BitSet) temp.clone();
        }

        BitSet decryptedBlock = new BitSet(BLOCK_SIZE);
        decryptedBlock.or(left);
        decryptedBlock.or(right);

        return decryptedBlock;
    }

    // Convert BitSet to a string of bits
    private static String bitSetToString(BitSet bitSet) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < bitSet.length(); i++) {
            sb.append(bitSet.get(i) ? '1' : '0');
        }
        return sb.toString();
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Generate two random keys
        BitSet key1 = generateRandomKey();
        BitSet key2 = generateRandomKey();

        System.out.println("Key 1: " + bitSetToString(key1));
        System.out.println("Key 2: " + bitSetToString(key2));

        // Input plaintext block
        System.out.print("Enter the plaintext block (16 bits): ");
        String plaintextStr = scanner.nextLine();
        BitSet plaintext = new BitSet(BLOCK_SIZE);
        for (int i = 0; i < plaintextStr.length(); i++) {
            if (plaintextStr.charAt(i) == '1') {
                plaintext.set(i);
            }
        }

        // Encrypt the plaintext
        BitSet ciphertext = encrypt(plaintext, key1, key2);
        System.out.println("Ciphertext: " + bitSetToString(ciphertext));

        // Decrypt the ciphertext
        BitSet decryptedText = decrypt(ciphertext, key1, key2);
        System.out.println("Decrypted plaintext: " + bitSetToString(decryptedText));
    }
}
