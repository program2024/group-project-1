
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.BitSet;
import java.util.Random;
import javax.swing.JOptionPane;

public class FiestelCipherGui extends javax.swing.JFrame {

    public FiestelCipherGui() {
        initComponents();
        setResizable(false);
        setLocationRelativeTo(null);
        getContentPane().setBackground(Color.white);
        ciphertextLabel.setText("");
        decryptedLabel.setText("");

        // Generate two random keys
        BitSet key1 = generateRandomKey();
        BitSet key2 = generateRandomKey();

        key1Label.setText("Key 1: " + bitSetToString(key1));
        key2Label.setText("Key 2: " + bitSetToString(key2));

        //calculate button
        calculateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String plaintextStr = textInput.getText().toString();
                if (plaintextStr.isEmpty()) {
                    message("Enter plain text");
                    return;
                }

                BitSet plaintext = new BitSet(BLOCK_SIZE);
                for (int i = 0; i < plaintextStr.length(); i++) {
                    if (plaintextStr.charAt(i) == '1') {
                        plaintext.set(i);
                    }
                }

                // Encrypt the plaintext
                BitSet ciphertext = encrypt(plaintext, key1, key2);
                ciphertextLabel.setText("Ciphertext: " + bitSetToString(ciphertext));

                // Decrypt the ciphertext
                BitSet decryptedText = decrypt(ciphertext, key1, key2);
                decryptedLabel.setText("Decrypted plaintext: " + bitSetToString(decryptedText));

            }
        });

    }

    private void message(String msg) {
        JOptionPane.showMessageDialog(rootPane, msg, "Fiestel Cipher", JOptionPane.ERROR_MESSAGE);
    }

    // Block size in bits
    private static final int BLOCK_SIZE = 16;
    // Key size in bits
    private static final int KEY_SIZE = 16;
    // Number of rounds
    private static final int NUM_ROUNDS = 2;

    // Generate a random 16-bit key
    private static BitSet generateRandomKey() {
        Random random = new Random();
        BitSet key = new BitSet(KEY_SIZE);
        for (int i = 0; i < KEY_SIZE; i++) {
            if (random.nextBoolean()) {
                key.set(i);
            }
        }
        return key;
    }

    // Round function: Shift by one byte and XOR operation
    private static BitSet roundFunction(BitSet block, BitSet key) {
        // Shift block by one byte
        block = shiftLeft(block);

        // XOR with key
        block.xor(key);

        return block;
    }

    // Shift left by one byte
    private static BitSet shiftLeft(BitSet bits) {
        int numBytes = bits.length() / 8;
        int numBits = bits.length() % 8;
        BitSet shiftedBits = new BitSet(bits.length());
        for (int i = 0; i < numBytes; i++) {
            for (int j = 0; j < 7; j++) {
                if (bits.get(i * 8 + j + 1)) {
                    shiftedBits.set(i * 8 + j);
                }
            }
            shiftedBits.set((i + 1) * 8 - 1);
        }
        // Handle remaining bits
        for (int i = 0; i < numBits - 1; i++) {
            if (bits.get(numBytes * 8 + i + 1)) {
                shiftedBits.set(numBytes * 8 + i);
            }
        }
        return shiftedBits;
    }

    // Fiestel encryption algorithm
    public static BitSet encrypt(BitSet block, BitSet key1, BitSet key2) {
        BitSet left = block.get(0, BLOCK_SIZE / 2);
        BitSet right = block.get(BLOCK_SIZE / 2, BLOCK_SIZE);

        for (int round = 0; round < NUM_ROUNDS; round++) {
            BitSet temp = (BitSet) right.clone();
            right.xor(roundFunction(left, key1));
            left = (BitSet) temp.clone();
        }

        right.xor(roundFunction(left, key2));

        BitSet encryptedBlock = new BitSet(BLOCK_SIZE);
        encryptedBlock.or(left);
        encryptedBlock.or(right);

        return encryptedBlock;
    }

    // Fiestel decryption algorithm
    public static BitSet decrypt(BitSet block, BitSet key1, BitSet key2) {
        BitSet left = block.get(0, BLOCK_SIZE / 2);
        BitSet right = block.get(BLOCK_SIZE / 2, BLOCK_SIZE);

        right.xor(roundFunction(left, key2));

        for (int round = 0; round < NUM_ROUNDS; round++) {
            BitSet temp = (BitSet) left.clone();
            left.xor(roundFunction(right, key1));
            right = (BitSet) temp.clone();
        }

        BitSet decryptedBlock = new BitSet(BLOCK_SIZE);
        decryptedBlock.or(left);
        decryptedBlock.or(right);

        return decryptedBlock;
    }

    // Convert BitSet to a string of bits
    private static String bitSetToString(BitSet bitSet) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < bitSet.length(); i++) {
            sb.append(bitSet.get(i) ? '1' : '0');
        }
        return sb.toString();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel00 = new javax.swing.JLabel();
        label_1 = new javax.swing.JLabel();
        textInput = new javax.swing.JTextField();
        calculateButton = new javax.swing.JButton();
        key2Label = new javax.swing.JLabel();
        key1Label = new javax.swing.JLabel();
        ciphertextLabel = new javax.swing.JLabel();
        decryptedLabel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel00.setFont(new java.awt.Font("Tahoma", 1, 28)); // NOI18N
        jLabel00.setForeground(new java.awt.Color(179, 74, 30));
        jLabel00.setText("Fiestel Cipher");

        label_1.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        label_1.setForeground(new java.awt.Color(0, 51, 51));
        label_1.setText("Enter the plaintext block (16 bits):");

        textInput.setFont(new java.awt.Font("Tahoma", 0, 22)); // NOI18N
        textInput.setForeground(new java.awt.Color(177, 73, 30));
        textInput.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        calculateButton.setBackground(new java.awt.Color(177, 73, 30));
        calculateButton.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        calculateButton.setForeground(new java.awt.Color(255, 255, 255));
        calculateButton.setText("Start");
        calculateButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                calculateButtonActionPerformed(evt);
            }
        });

        key2Label.setFont(new java.awt.Font("Tahoma", 0, 19)); // NOI18N
        key2Label.setForeground(new java.awt.Color(102, 102, 102));
        key2Label.setText("Enter the plaintext block (16 bits):");

        key1Label.setFont(new java.awt.Font("Tahoma", 0, 19)); // NOI18N
        key1Label.setForeground(new java.awt.Color(102, 102, 102));
        key1Label.setText("Enter the plaintext block (16 bits):");

        ciphertextLabel.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        ciphertextLabel.setForeground(new java.awt.Color(179, 74, 30));
        ciphertextLabel.setText("Enter the plaintext block (16 bits):");

        decryptedLabel.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        decryptedLabel.setForeground(new java.awt.Color(51, 51, 51));
        decryptedLabel.setText("Enter the plaintext block (16 bits):");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel00)
                .addGap(321, 321, 321))
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(key1Label)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(key2Label)
                .addGap(25, 25, 25))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(195, 195, 195)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(65, 65, 65)
                                .addComponent(label_1))
                            .addComponent(textInput, javax.swing.GroupLayout.PREFERRED_SIZE, 436, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(332, 332, 332)
                        .addComponent(calculateButton, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(61, 61, 61)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(decryptedLabel)
                            .addComponent(ciphertextLabel))))
                .addContainerGap(195, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel00)
                .addGap(28, 28, 28)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(key1Label)
                    .addComponent(key2Label))
                .addGap(47, 47, 47)
                .addComponent(label_1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(textInput, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(56, 56, 56)
                .addComponent(calculateButton, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(63, 63, 63)
                .addComponent(ciphertextLabel)
                .addGap(29, 29, 29)
                .addComponent(decryptedLabel)
                .addContainerGap(41, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void calculateButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_calculateButtonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_calculateButtonActionPerformed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FiestelCipherGui().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton calculateButton;
    private javax.swing.JLabel ciphertextLabel;
    private javax.swing.JLabel decryptedLabel;
    private javax.swing.JLabel jLabel00;
    private javax.swing.JLabel key1Label;
    private javax.swing.JLabel key2Label;
    private javax.swing.JLabel label_1;
    private javax.swing.JTextField textInput;
    // End of variables declaration//GEN-END:variables
}
